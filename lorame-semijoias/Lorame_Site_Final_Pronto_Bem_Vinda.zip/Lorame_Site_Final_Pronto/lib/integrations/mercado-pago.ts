// Server-only adapter. Enable only after verifying provider credentials,
// delivery quotation, inventory reservations and signed payment webhooks.
// The current checkout intentionally never invokes this adapter.
export type PaymentItem={id:string;name:string;quantity:number;unitPriceCents:number};
export async function createPaymentPreference(input:{orderId:string;items:PaymentItem[];origin:string},token:string){
 if(!token)throw Error('Mercado Pago não configurado.');
 const origin=new URL(input.origin);if(origin.protocol!=='https:')throw Error('Origem HTTPS obrigatória.');
 const response=await fetch('https://api.mercadopago.com/checkout/preferences',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json','X-Idempotency-Key':input.orderId},body:JSON.stringify({external_reference:input.orderId,items:input.items.map(i=>({id:i.id,title:i.name,quantity:i.quantity,currency_id:'BRL',unit_price:i.unitPriceCents/100})),back_urls:{success:origin.origin+'/minha-conta',pending:origin.origin+'/minha-conta',failure:origin.origin+'/checkout'}})});
 if(!response.ok)throw Error('Não foi possível iniciar o pagamento.');
 const result=await response.json() as {id:string;init_point:string};return {id:result.id,url:result.init_point};
}
