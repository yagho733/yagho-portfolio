export const FIRST_PURCHASE_COUPON_CODE='Bem vinda';
export const FIRST_PURCHASE_COUPON_PERCENT=10;

export function normalizeCouponCode(value:unknown){
  return String(value??'').trim().replace(/\s+/g,' ').toLocaleUpperCase('pt-BR');
}

export function isFirstPurchaseCoupon(value:unknown){
  return normalizeCouponCode(value)===normalizeCouponCode(FIRST_PURCHASE_COUPON_CODE);
}
