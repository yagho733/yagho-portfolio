/** Integer centavos throughout. Discounts round per unit so the displayed
 * Pix unit price multiplied by quantity always equals the item total. */
export function pixPrice(price:number,percent:number){return Math.round(price*(100-percent)/100)}
export function quote<T extends {price:number;qty:number}>(items:T[],config:{pix_discount:number;minimum_order_value:number;free_shipping_threshold:number;shipping_fee:number},couponPercent=0,payment='pix'){
 const lines=items.map(item=>{const couponUnit=item.price-Math.round(item.price*couponPercent/100);const unitTotal=payment==='pix'?pixPrice(couponUnit,config.pix_discount):couponUnit;return {...item,unitTotal,lineTotal:unitTotal*item.qty,couponDiscount:(item.price-couponUnit)*item.qty,pixDiscount:(couponUnit-unitTotal)*item.qty}});
 const subtotal=lines.reduce((sum,item)=>sum+item.price*item.qty,0);
 const couponDiscount=lines.reduce((sum,item)=>sum+item.couponDiscount,0);
 const pixDiscount=lines.reduce((sum,item)=>sum+item.pixDiscount,0);
 const productsTotal=lines.reduce((sum,item)=>sum+item.lineTotal,0);
 const shippingFee=config.free_shipping_threshold>0&&subtotal>=config.free_shipping_threshold?0:config.shipping_fee>0?config.shipping_fee:null;
 return {items:lines,subtotal,couponDiscount,pixDiscount,productsTotal,shippingFee,total:productsTotal+(shippingFee??0)};
}
