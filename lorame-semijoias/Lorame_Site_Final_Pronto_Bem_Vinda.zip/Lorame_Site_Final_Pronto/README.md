# Lorâme — continuação do projeto original

Esta versão continua a entrega original de 25/09/2026 (commit 14bcaa70931a6c602325a2993b36751f5273e1d7). Não é um projeto novo.

## Operação

- Catálogo, busca, filtros, variantes, favoritos e sacola persistem no banco D1.
- Finalização de visitante ou cliente identificado pelo WhatsApp. Sem checkout de teste ou cobrança online.
- Pedido gera mensagem com cliente, endereço, produtos, variantes, quantidade, preço unitário, descontos, frete e total. A cliente confirma o envio no WhatsApp.
- Sem frete definido, o valor é identificado como total das peças e o frete fica a combinar. Frete fixo e faixa de gratuidade são configuráveis.
- Pix e cupons usam centavos inteiros. Cupom é aplicado primeiro por unidade; Pix arredonda o preço unitário resultante. A quantidade multiplica esse valor. A mesma função é utilizada na sacola e no servidor.
- Cupom de primeira compra: `Bem vinda`, com 10% de desconto. O código aceita diferenças de maiúsculas/minúsculas e espaços extras, mas é exibido como “Bem vinda”. A API bloqueia reaplicação após um pedido anterior do mesmo cliente/sessão e revalida também o e-mail no fechamento do pedido.
- Pedido pendente não reserva estoque. Confirmar no painel baixa estoque em transação; cancelar devolve. Conflitos concorrentes abortam a transação, evitando baixa duplicada.
- Estoque é compartilhado entre as variantes de cada produto. Para estoques independentes por banho, cadastre produtos separados.
- Admin permite criar, editar e desativar produtos; URLs de imagens, categorias, coleções, variantes, preços e estoque; configurações comerciais, cupons, banner e políticas; consulta de clientes e atualização dos pedidos.
- Preço Pix deriva do desconto percentual central, editável em Condições da loja.
- Monograma e flor em WebP com alpha verdadeiro; favicon PNG transparente.

## Ativar a loja

1. Acessar `/admin` com a conta ChatGPT proprietária `yaghosantoa1@gmail.com`. A autorização é conferida no servidor via `ADMIN_EMAIL`, já configurado na hospedagem. Não há senha administrativa no código.
2. Em Produtos, cadastrar fotos, preços, estoque e especificações reais. Desmarcar “Produto demonstrativo” somente após conferir os dados. Desativar os modelos que não serão vendidos.
3. Em Condições da loja, informar o WhatsApp oficial com país e DDD, pedido mínimo, desconto Pix e entrega. Zero em frete fixo significa “a combinar”; zero no limite de frete grátis desativa esse benefício.
4. Revisar Conteúdo e políticas, Instagram e prazos. Nenhum prazo comercial, CNPJ ou contato foi inventado.
5. Ativar “Receber pedidos pelo WhatsApp”. O servidor bloqueia finalização sem número, com loja inativa, com produtos demonstrativos, fora de estoque ou abaixo do mínimo.
6. Liberar o acesso público da hospedagem quando o catálogo real estiver aprovado. A audiência privada existente foi preservada.

O número não foi informado pelo proprietário (escolheu configurar depois). O catálogo original possui fotos e produtos demonstrativos; não foram convertidos em estoque real artificialmente.

## Abrir no Cursor / Windows

1. Extrair o ZIP e abrir a pasta no Cursor.
2. Usar Node.js 24 ou superior e pnpm 11.25.0.
3. Executar `pnpm install --frozen-lockfile`.
4. Copiar `.env.example` para `.env` se necessário. Nunca publicar esse arquivo com segredos.
5. Em uma instalação nova, executar `pnpm db:local` e depois `pnpm dev`. Na execução portátil o servidor utiliza a porta 5173.
6. O banco D1 local precisa receber as migrações em `drizzle/`, na ordem, antes das operações da loja. A publicação Sites aplica as migrações existentes. Não apague migrações já aplicadas.

### Verificação

- `pnpm typecheck`
- `pnpm lint`
- `pnpm build`
- `pnpm test` (após build; banco temporário isolado com migrações aplicadas automaticamente)

### Hospedagem e portabilidade

O projeto existente é Next App Router/React/TypeScript sobre Vinext e Cloudflare Workers, com D1 e autenticação do Sites. Preserve `.openai/hosting.json` e seu project_id. O ZIP contém código e assets, não exporta pedidos ou dados privados do banco hospedado.

Não implantar diretamente na Vercel sem adaptar os acessos a D1 e autenticação. Fora do Sites, cabeçalhos de identidade nunca devem ser confiados diretamente da internet: use um provedor de identidade validado no servidor. `ADMIN_EMAIL` sozinho não autentica ninguém.

O adaptador Mercado Pago permanece isolado e não é usado pela loja. Não há credenciais, cobrança simulada ou coleta de cartão. Uma futura integração exigirá webhook autenticado, conciliação e testes próprios.

Consulte VALIDATION.md para a abrangência real dos testes e PROMPT_CURSOR.md para continuidade.
