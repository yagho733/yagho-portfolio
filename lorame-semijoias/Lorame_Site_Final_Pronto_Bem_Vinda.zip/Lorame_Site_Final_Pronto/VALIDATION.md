# Validação — 28/09/2026

Continuação do projeto original 14bcaa70931a6c602325a2993b36751f5273e1d7.

## Correções e testes
- Preço Pix centralizado em centavos por unidade, compartilhado por produto, sacola e pedido; testes com quantidade e cupom, sem diferença de centavos.
- Corrigido UUID em navegadores de desenvolvimento HTTP, usando gerador criptográfico compatível.
- Banco local novo: migrações executadas com sucesso; instalação documentada.
- Testes automatizados em banco isolado: sacola persistida, variantes e estoque, favoritos, autorização admin, bloqueio por origem, mínimo, cupom, pedido de visitante e cliente, idempotência, isolamento entre contas, confirmação/cancelamento com estoque, produtos ativos/inativos, banner e políticas.
- WhatsApp: texto, acentos, quebras de linha, URL e total conferidos automaticamente. Não foi enviada mensagem real. Número oficial ainda não configurado.
- Navegador: busca, filtros, produto, variante, inclusão, aumento/redução, remoção, mínimo e valores até a tela de finalização. A finalização pública permanece bloqueada corretamente enquanto a loja não for ativada.
- Home, catálogo, produto, sacola e checkout medidos em 320, 375, 390, 414, 430, 768, 1366, 1440 e 1920 pixels, sem overflow de documento; inspeção visual em celular e desktop. Navegação horizontal de categorias é intencional.
- 21 rotas renderizadas; rota inexistente retorna 404; imagens do catálogo retornam 200.
- Logo/monograma e flor possuem canal alpha real, sem mix-blend-mode.
- Acesso administrativo autorizado e negado testado no servidor. Login OAuth da conta real e cada controle visual do admin não foram validados em sessão autenticada no navegador; não foi criado bypass.
- Console: erro de UUID corrigido; mensagens da extensão do navegador não pertencem à aplicação.

## Verificação técnica
Typecheck, lint, build e testes executados na versão entregue. Lint sem erros, com avisos existentes de uso de img em assets locais. Nenhum gateway de pagamento simulado ativo.

## Condições para operação real
Configurar WhatsApp oficial, substituir/validar catálogo demonstrativo e políticas reais, ativar recebimento de pedidos e liberar audiência pública na hospedagem. O projeto continua privado. O ZIP não inclui dados privados do banco hospedado, dependências instaladas ou segredos.

A portabilidade da autenticação e do banco para outra hospedagem exige adaptação documentada no README; não confundir configuração de e-mail com um provedor de login.
