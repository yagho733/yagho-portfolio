import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import {resolve} from 'node:path';
const require=createRequire(import.meta.url);
const {Miniflare}=await import(require.resolve('miniflare',{paths:[require.resolve('wrangler')]}));
// Same local-only binding ID and persistence directory used by vite.config.ts.
const mf=new Miniflare({modules:true,script:'export default {fetch(){return new Response("local migrations")}}',d1Databases:{DB:'00000000-0000-4000-8000-000000000000'},d1Persist:resolve('.wrangler/state/v3/d1')});
try{
 const db=await mf.getD1Database('DB');
 await db.prepare('CREATE TABLE IF NOT EXISTS _lorame_local_migrations(name TEXT PRIMARY KEY)').run();
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort()){
  if(await db.prepare('SELECT name FROM _lorame_local_migrations WHERE name=?').bind(file).first())continue;
  const statements=(await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean);
  await db.batch([...statements.map(sql=>db.prepare(sql)),db.prepare('INSERT INTO _lorame_local_migrations(name) VALUES (?)').bind(file)]);
  console.log('Aplicada: '+file);
 }
 console.log('Banco local preparado.');
}finally{await mf.dispose()}
