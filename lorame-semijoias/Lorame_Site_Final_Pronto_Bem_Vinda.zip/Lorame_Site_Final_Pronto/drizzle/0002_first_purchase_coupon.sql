INSERT INTO `coupons` (`code`,`percent`,`active`) VALUES ('Bem vinda',10,1)
ON CONFLICT(`code`) DO UPDATE SET `percent`=excluded.`percent`,`active`=excluded.`active`;
