CREATE TABLE `addresses` (
	`id` text PRIMARY KEY NOT NULL,
	`customerId` text NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `addresses_customer` ON `addresses` (`customerId`);--> statement-breakpoint
CREATE TABLE `cart` (
	`owner` text NOT NULL,
	`productId` text NOT NULL,
	`variant` text NOT NULL,
	`qty` integer NOT NULL,
	PRIMARY KEY(`owner`, `productId`, `variant`)
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `coupons` (
	`code` text PRIMARY KEY NOT NULL,
	`percent` integer NOT NULL,
	`active` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `favorites` (
	`owner` text NOT NULL,
	`productId` text NOT NULL,
	PRIMARY KEY(`owner`, `productId`)
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` text PRIMARY KEY NOT NULL,
	`orderId` text NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `items_order` ON `order_items` (`orderId`);--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`customerId` text NOT NULL,
	`status` text NOT NULL,
	`data` text NOT NULL,
	`createdAt` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `orders_customer` ON `orders` (`customerId`);--> statement-breakpoint
CREATE TABLE `product_images` (
	`id` text PRIMARY KEY NOT NULL,
	`productId` text NOT NULL,
	`url` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `product_variants` (
	`id` text PRIMARY KEY NOT NULL,
	`productId` text NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` text PRIMARY KEY NOT NULL,
	`slug` text NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `products_slug_unique` ON `products` (`slug`);--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`productId` text NOT NULL,
	`data` text NOT NULL,
	`approved` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `store_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL
);
