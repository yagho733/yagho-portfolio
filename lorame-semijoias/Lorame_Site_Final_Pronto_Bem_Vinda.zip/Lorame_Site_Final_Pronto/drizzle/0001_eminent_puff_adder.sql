CREATE TABLE `cart_settings` (
	`owner` text PRIMARY KEY NOT NULL,
	`coupon` text NOT NULL
);
