import {seedProducts,pages,categories,slugify} from '@/lib/catalog';
import {catalog} from '@/lib/server';
export default async function sitemap(){let products=seedProducts;try{products=await catalog()}catch{}return ['','produtos','revenda','faq',...Object.keys(pages),...categories.map(c=>'categoria/'+slugify(c)),...products.map(p=>'produto/'+p.slug)].map(path=>({url:'https://lorame-semijoias.yaghosantoa1.chatgpt.site/'+path}))}
