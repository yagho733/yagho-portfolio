'use client';
export default function Error({reset}:{reset:()=>void}){return <section className="empty"><h1>Uma pausa inesperada.</h1><p>Não foi possível carregar esta página. Suas escolhas continuam salvas.</p><button className="btn" onClick={reset}>Tentar novamente</button></section>}
