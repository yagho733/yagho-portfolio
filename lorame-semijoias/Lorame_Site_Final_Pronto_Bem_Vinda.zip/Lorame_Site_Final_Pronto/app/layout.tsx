import type {Metadata} from 'next';
import './globals.css';
import {StoreProvider,Shell} from '@/components/store';
export const metadata:Metadata={metadataBase:new URL('https://lorame-semijoias.yaghosantoa1.chatgpt.site'),title:{default:'Lorâme | Semijoias para revenda',template:'%s | Lorâme'},description:'Descubra a seleção Lorâme de semijoias para revenda. Brincos, colares, anéis e pulseiras em uma experiência de compra feita com cuidado.',icons:{icon:'/icon.png'},openGraph:{title:'Lorâme | Semijoias para revenda',description:'Uma seleção de semijoias para quem vende com elegância.',locale:'pt_BR',type:'website'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body><StoreProvider><Shell>{children}</Shell></StoreProvider></body></html>}
