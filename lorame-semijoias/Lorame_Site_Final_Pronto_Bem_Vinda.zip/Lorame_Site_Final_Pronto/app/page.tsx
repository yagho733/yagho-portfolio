import {Home} from '@/components/home';
export const metadata={alternates:{canonical:'/'}};
export default function Page(){return <><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify({'@context':'https://schema.org','@type':'Organization',name:'Lorâme',url:'https://lorame-semijoias.yaghosantoa1.chatgpt.site'})}}/><Home/></>}
