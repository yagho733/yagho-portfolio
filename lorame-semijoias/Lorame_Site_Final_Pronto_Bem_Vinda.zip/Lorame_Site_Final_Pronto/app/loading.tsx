import {Skeleton} from '@/components/ui/skeleton';
export default function Loading(){return <div className="container section" aria-label="Carregando"><Skeleton className="h-14 w-64 mb-8"/><div className="products">{[1,2,3,4].map(n=><Skeleton key={n} className="h-80 w-full"/>)}</div></div>}
